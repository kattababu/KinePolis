/**
 * 
 */
package com.Nutch.Crawl.KineP;

/**
 * @author surendra
 *
 */
public class KinePolisMain {

	/**
	 * 
	 */
	public KinePolisMain() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 * @throws Throwable 
	 */
	public static void main(String[] args)  {
		// TODO Auto-generated method stub

		KinePolisCNRows kpcr=new KinePolisCNRows();
		
		
		kpcr.KinePolisCR();
		//kpcr.KinePolisCRM();
	}
	
	
	
	
}

