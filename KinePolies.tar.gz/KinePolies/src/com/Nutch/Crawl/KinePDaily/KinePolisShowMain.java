/**
 * 
 */
package com.Nutch.Crawl.KinePDaily;

/**
 * @author surendra
 *
 */
public class KinePolisShowMain {

	/**
	 * 
	 */
	public KinePolisShowMain() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new KinePolisAvailTheater().KinePolisATTCNT();
		
		
	}

}
